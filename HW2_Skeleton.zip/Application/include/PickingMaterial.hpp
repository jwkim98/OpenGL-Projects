#pragma once

#include <Material.hpp>

class PickingMaterial : public Engine::Material
{
private:

public:
    void CreateMaterial();
};